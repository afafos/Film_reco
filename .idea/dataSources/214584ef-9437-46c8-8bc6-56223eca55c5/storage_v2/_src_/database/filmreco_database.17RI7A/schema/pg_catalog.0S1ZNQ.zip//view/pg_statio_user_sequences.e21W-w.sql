create view pg_statio_user_sequences(relid, schemaname, relname, blks_read, blks_hit) as
SELECT relid,
       schemaname,
       relname,
       blks_read,
       blks_hit
FROM pg_statio_all_sequences
WHERE (schemaname <> ALL (ARRAY ['pg_catalog'::name, 'information_schema'::name]))
  AND schemaname !~ '^pg_toast'::text;

alter table pg_statio_user_sequences
    owner to postgres;

grant select on pg_statio_user_sequences to public;

